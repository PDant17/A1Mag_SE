src/Life.d src/Life.o: ../src/Life.c
